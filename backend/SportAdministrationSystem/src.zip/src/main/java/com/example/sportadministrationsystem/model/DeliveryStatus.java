package com.example.sportadministrationsystem.model;

public enum DeliveryStatus {
    SENT, FAILED
}
