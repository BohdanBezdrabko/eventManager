package com.example.sportadministrationsystem.model;

public enum Status {

}
