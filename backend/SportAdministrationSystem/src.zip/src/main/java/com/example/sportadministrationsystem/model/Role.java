package com.example.sportadministrationsystem.model;

public enum Role {
    ROLE_USER,   // Учасник
    ROLE_ADMIN   // Організатор (створює івенти)
}
