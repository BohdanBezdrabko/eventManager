package com.example.sportadministrationsystem.model;

public enum Messenger {
    TELEGRAM
}
