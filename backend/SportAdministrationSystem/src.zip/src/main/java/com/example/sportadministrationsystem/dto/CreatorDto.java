package com.example.sportadministrationsystem.dto;

public record CreatorDto(Long id, String username) {}
