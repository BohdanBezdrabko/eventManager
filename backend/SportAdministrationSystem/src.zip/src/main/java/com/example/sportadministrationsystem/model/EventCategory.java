package com.example.sportadministrationsystem.model;

public enum EventCategory {
    SPORTS, EDUCATION, MUSIC, COMMUNITY, OTHER
}
