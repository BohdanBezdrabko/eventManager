package com.example.sportadministrationsystem.model;

public enum PostStatus {DRAFT, SCHEDULED, PUBLISHED, FAILED, CANCELED}
