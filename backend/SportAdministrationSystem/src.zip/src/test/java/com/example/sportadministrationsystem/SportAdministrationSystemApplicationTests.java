package com.example.sportadministrationsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportAdministrationSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
