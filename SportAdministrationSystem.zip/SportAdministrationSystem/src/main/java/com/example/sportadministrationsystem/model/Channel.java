package com.example.sportadministrationsystem.model;

public enum Channel {TELEGRAM, INTERNAL}
