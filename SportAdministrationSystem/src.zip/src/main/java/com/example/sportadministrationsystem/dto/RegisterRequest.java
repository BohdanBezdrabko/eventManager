package com.example.sportadministrationsystem.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RegisterRequest(
        String username,
        String password,
        @JsonProperty("role") String role
) {}
