package com.example.sportadministrationsystem.service;

import com.example.sportadministrationsystem.dto.UserInfoDTO;

public interface UserService {
    UserInfoDTO getCurrentUserInfo();
}
