// src/pages/LoginPage.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useLocation, useNavigate, Link } from "react-router-dom";

export default function LoginPage() {
    const { login, user } = useAuth();
    const [form, setForm] = useState({ username: "", password: "" });
    const [error, setError] = useState("");
    const navigate = useNavigate();
    const location = useLocation();

    const from = new URLSearchParams(location.search).get("from") || "/dashboard";

    useEffect(() => { if (user) navigate("/dashboard", { replace: true }); }, [user, navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        try {
            await login(form.username, form.password);
            navigate(from, { replace: true });
        } catch (err) {
            setError(err.message || "Помилка входу");
        }
    };

    return (
        <div className="container py-4">
            <h2>Вхід</h2>
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label className="form-label">Логін</label>
                    <input className="form-control" value={form.username}
                           onChange={e => setForm(f => ({ ...f, username: e.target.value }))} />
                </div>
                <div className="mb-3">
                    <label className="form-label">Пароль</label>
                    <input type="password" className="form-control" value={form.password}
                           onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
                </div>
                <button className="btn btn-primary" type="submit">Увійти</button>
                <Link to="/register" className="btn btn-link">Реєстрація</Link>
            </form>
        </div>
    );
}
