// src/pages/EventsPage.jsx
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getAllEvents } from "@/services/events";
import { Calendar, MapPin } from "lucide-react";

export default function EventsPage() {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState(null);

    useEffect(() => {
        let cancelled = false;
        (async () => {
            try {
                const data = await getAllEvents();
                if (!cancelled) setEvents(Array.isArray(data) ? data : []);
            } catch (e) {
                if (!cancelled) setErr(e.message || "Помилка");
            } finally {
                if (!cancelled) setLoading(false);
            }
        })();
        return () => { cancelled = true; };
    }, []);

    if (loading) return <div className="container py-4">Завантаження…</div>;
    if (err) return <div className="container py-4 text-danger">Помилка: {String(err)}</div>;

    return (
        <div className="container py-4">
            <h2 className="mb-3">Івенти</h2>
            {events.length === 0 ? (
                <p className="text-muted">Поки немає івентів.</p>
            ) : (
                <div className="row g-3">
                    {events.map((e) => (
                        <div key={e.id} className="col-12 col-md-6 col-lg-4">
                            <div className="card h-100 shadow-sm">
                                {e.cover && <img src={e.cover} alt="" className="card-img-top" />}
                                <div className="card-body d-flex flex-column">
                                    <h5 className="card-title mb-2">{e.name}</h5>
                                    <div className="text-muted small mb-3 d-flex gap-3 flex-wrap">
                    <span className="d-inline-flex align-items-center gap-1">
                      <Calendar size={16} /> {formatDate(e.date)}
                    </span>
                                        <span className="d-inline-flex align-items-center gap-1">
                      <MapPin size={16} /> {e.location || "—"}
                    </span>
                                    </div>
                                    <div className="mt-auto">
                                        <Link to={`/events/${e.id}`} className="btn btn-primary w-100">
                                            Деталі
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

function formatDate(iso) {
    if (!iso) return "-";
    const d = new Date(iso);
    if (Number.isNaN(d)) return iso;
    return d.toLocaleDateString();
}
