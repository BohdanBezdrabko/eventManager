const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8081";

// ===== Token storage =====
function setTokens({ accessToken, refreshToken }) {
    if (accessToken) localStorage.setItem("accessToken", accessToken);
    if (refreshToken) localStorage.setItem("refreshToken", refreshToken);
}
function getAccessToken() {
    return localStorage.getItem("accessToken");
}
function getRefreshToken() {
    return localStorage.getItem("refreshToken");
}
function clearToken() {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
}

export { setTokens, getAccessToken, getRefreshToken, clearToken };

async function readError(res) {
    const txt = await res.text();
    try {
        const parsed = JSON.parse(txt);
        return parsed.message || txt || res.statusText;
    } catch {
        return txt || res.statusText;
    }
}

// ===== Auth API =====

/**
 * Реєстрація: очікуємо { accessToken, refreshToken, user }.
 */
export async function registerUser({ username, password, role = "participant" }) {
    const res = await fetch(`${API_URL}/api/v1/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password, role }),
    });

    if (!res.ok) {
        throw new Error((await readError(res)) || "Registration failed");
    }

    const data = await res.json(); // { accessToken, refreshToken, user }
    if (!data?.accessToken || !data?.user) {
        throw new Error("Invalid response from server");
    }

    setTokens(data);
    return data;
}

/**
 * Логін: очікуємо { accessToken, refreshToken, user }.
 */
export async function loginUser({ username, password }) {
    const res = await fetch(`${API_URL}/api/v1/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
    });

    if (!res.ok) {
        throw new Error((await readError(res)) || "Login failed");
    }

    const data = await res.json(); // { accessToken, refreshToken, user }
    if (!data?.accessToken || !data?.user) {
        throw new Error("Invalid response from server");
    }

    setTokens(data);
    return data;
}

/**
 * Отримати поточного користувача з бекенду.
 */
export async function getCurrentUser() {
    const token = getAccessToken();
    if (!token) throw new Error("No token");

    const res = await fetch(`${API_URL}/api/v1/users/me`, {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` },
    });

    if (res.status === 401) {
        clearTokens();
        throw new Error("Unauthorized");
    }

    if (!res.ok) {
        throw new Error((await readError(res)) || "Не вдалося отримати дані користувача");
    }

    return res.json();
}

/** Логаут: просто чистимо токени */
export function logoutUser() {
    clearTokens();
}

// Хелпер для додавання Authorization у ваші інші fetch-и:
export function authHeaders(extra = {}) {
    const token = getAccessToken();
    return token ? { ...extra, Authorization: `Bearer ${token}` } : extra;
}

// Універсальний fetch з токеном та базовою обробкою
export async function authFetch(path, options = {}) {
    const url = path.startsWith("http") ? path : `${API_URL}${path}`;
    const res = await fetch(url, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            ...authHeaders(options.headers),
        },
    });

    if (res.status === 401) {
        clearTokens();
        throw new Error("Unauthorized");
    }

    if (res.status === 204) return null;

    const text = await res.text();
    if (!text) return null;
    try {
        return JSON.parse(text);
    } catch {
        return text;
    }
}
