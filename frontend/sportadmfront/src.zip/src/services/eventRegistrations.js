import { http } from "@/utils/fetchWrapper";

const BASE = "/registrations";

export function getMyRegistrations() {
    return http.get(`${BASE}/my`);
}

export function getUserEventsByUserId(_userId) {
    return getMyRegistrations();
}

export function registerForEvent(eventId) {
    return http.post(`${BASE}/my/${encodeURIComponent(eventId)}`);
}

export function cancelRegistration(eventId) {
    return http.delete(`${BASE}/my/${encodeURIComponent(eventId)}`);
}

export function getEventById(eventId) {
    return http.get(`/events/${encodeURIComponent(eventId)}`);
}
