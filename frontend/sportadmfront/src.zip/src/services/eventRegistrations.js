import { http } from "@/utils/fetchWrapper.jsx";
import { authJson } from "@/services/auth.jsx";

/** Отримати userId: з пропса або через /auth/me (із токеном) */
async function resolveUserId(user) {
    if (user?.id) return user.id;
    const me = await authJson("/auth/me"); // відправляє Authorization автоматично
    if (!me?.id) throw new Error("No user id");
    return me.id;
}

/** Мої реєстрації за userId (один запит, без спроб за username) */
export async function getUserEvents(user) {
    const id = await resolveUserId(user);
    return http.get(`/registrations/user-id/${id}`); // додає Authorization: Bearer <token>
}
