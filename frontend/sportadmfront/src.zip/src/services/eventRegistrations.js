import { getAccessToken  } from "./auth.jsx";

const API_URL = (import.meta.env.VITE_API_URL || "http://localhost:8081") + "/api/v1/registrations";

export async function getUserEvents(userId) {
    const res = await fetch(`${API_URL}/user/${userId}`, {
        headers: {
            "Authorization": `Bearer ${getAccessToken ()}`,
            "Content-Type": "application/json",
        },
    });
    if (!res.ok) throw new Error("Не вдалося завантажити івенти користувача");
    return res.json();
}
