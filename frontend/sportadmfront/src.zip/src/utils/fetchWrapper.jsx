// src/utils/fetchWrapper.jsx
import { getToken, clearToken } from "../services/auth.jsx";

function apiUrl(path) {
    const ROOT = (import.meta.env.VITE_API_URL || "http://localhost:8081/api/v1").replace(/\/+$/, "");
    return /^https?:\/\//i.test(path) ? path : `${ROOT}${path.startsWith("/") ? path : `/${path}`}`;
}

export async function request(path, init = {}) {
    const headers = new Headers(init.headers || {});
    if (!(init.body instanceof FormData)) {
        headers.set("Accept", "application/json");
        if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
    }
    const t = getToken(); if (t) headers.set("Authorization", `Bearer ${t}`);

    const res = await fetch(apiUrl(path), { ...init, headers });

    if (res.status === 401 || res.status === 403) {
        try { await res.text(); } catch {}
        clearToken();
        // не редіректимо тут; нехай це робить RouteGuard
        throw new Error(`Unauthorized ${res.status}`);
    }
    if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`HTTP ${res.status} ${text}`);
    }
    const ct = res.headers.get("content-type") || "";
    return ct.includes("application/json") ? res.json() : res.text();
}

export const http = {
    get: (p) => request(p, { method: "GET" }),
    post: (p, body) => request(p, { method: "POST", body: body instanceof FormData ? body : JSON.stringify(body ?? {}) }),
    put: (p, body) => request(p, { method: "PUT", body: body instanceof FormData ? body : JSON.stringify(body ?? {}) }),
    patch: (p, body) => request(p, { method: "PATCH", body: body instanceof FormData ? body : JSON.stringify(body ?? {}) }),
    delete: (p) => request(p, { method: "DELETE" }),
};
