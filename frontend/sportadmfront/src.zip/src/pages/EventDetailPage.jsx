import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getEventById, registerForEvent, cancelRegistration } from "@/services/eventRegistrations";

export default function EventDetailsPage() {
    const { id } = useParams();
    const [ev, setEv] = useState(null);
    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState("");

    useEffect(() => {
        let off = false;
        (async () => {
            try {
                setLoading(true);
                const data = await getEventById(id);
                if (!off) setEv(data);
            } catch (e) {
                if (!off) setErr(e?.message || "Помилка завантаження");
            } finally {
                if (!off) setLoading(false);
            }
        })();
        return () => { off = true; };
    }, [id]);

    async function onRegister() {
        try {
            await registerForEvent(id);
            alert("Ви зареєстровані");
        } catch (e) {
            alert(e?.message || "Не вдалося зареєструватися");
        }
    }

    async function onCancel() {
        try {
            await cancelRegistration(id);
            alert("Реєстрацію скасовано");
        } catch (e) {
            alert(e?.message || "Не вдалося скасувати");
        }
    }

    if (loading) return <div className="container py-4">Завантаження…</div>;
    if (err) return <div className="container py-4"><div className="alert alert-danger">{err}</div></div>;
    if (!ev) return null;

    return (
        <div className="container py-4">
            <Link to="/events" className="btn btn-outline-secondary mb-3">← До списку</Link>
            <h1 className="mb-2">{ev.name || ev.title || "Подія"}</h1>
            <div className="text-muted mb-3">
                {(ev.startAt || ev.date || ev.datetime) ?? "без дати"} • {ev.location || "—"}
            </div>
            <p className="mb-4">{ev.description || "Опис відсутній."}</p>
            <div className="d-flex gap-2">
                <button className="btn btn-primary" onClick={onRegister}>Зареєструватися</button>
                <button className="btn btn-outline-danger" onClick={onCancel}>Скасувати</button>
            </div>
        </div>
    );
}
