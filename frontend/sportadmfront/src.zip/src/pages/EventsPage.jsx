// ===============================
// File: src/pages/EventsPage.jsx
// Призначення: сторінка ЛІСТИНГУ подій (усі івенти)
// Виправляє баг з викликом /events/undefined на маршруті /events
// ===============================
import { useEffect, useMemo, useState, useCallback } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { getAllEvents } from "@/services/events.jsx";

function useAsync() {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const run = useCallback(async (fn) => {
        setLoading(true);
        setError(null);
        try {
            const r = await fn();
            setLoading(false);
            return r;
        } catch (e) {
            setLoading(false);
            setError(e);
            throw e;
        }
    }, []);
    return { loading, error, run };
}

export default function EventsPage() {
    const navigate = useNavigate();
    const [searchParams, setSearchParams] = useSearchParams();

    // query-параметри з адреси
    const page = Number(searchParams.get("page") || 0);
    const size = Number(searchParams.get("size") || 20);
    const sort = searchParams.get("sort") || "startAt,asc";
    const category = searchParams.get("category") || "";
    const tag = searchParams.get("tag") || "";

    const [{ content, totalElements, totalPages }, setData] = useState({
        content: [],
        totalElements: 0,
        totalPages: 0,
    });

    const { loading, error, run } = useAsync();

    useEffect(() => {
        run(async () => {
            const pageData = await getAllEvents({ page, size, sort, category, tag });
            // очікуємо Spring Data Page<EventDto>
            setData({
                content: pageData.content || [],
                totalElements: pageData.totalElements ?? 0,
                totalPages: pageData.totalPages ?? 0,
            });
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page, size, sort, category, tag]);

    const onChangeFilter = (e) => {
        const { name, value } = e.target;
        const next = new URLSearchParams(searchParams);
        if (value) next.set(name, value); else next.delete(name);
        next.set("page", "0"); // при зміні фільтра повертаємося на першу сторінку
        setSearchParams(next);
    };

    const gotoPage = (p) => {
        const next = new URLSearchParams(searchParams);
        next.set("page", String(p));
        setSearchParams(next);
    };

    const onSort = (field) => {
        const [curField, curDir = "asc"] = sort.split(",");
        const dir = curField === field && curDir.toLowerCase() === "asc" ? "desc" : "asc";
        const next = new URLSearchParams(searchParams);
        next.set("sort", `${field},${dir}`);
        next.set("page", "0");
        setSearchParams(next);
    };

    return (
        <div className="ev-wrap">
            <div className="ev-topbar">
                <h1 className="ev-h1">Івенти</h1>
                <Link className="ev-btn" to="/events/create">Створити івент</Link>
            </div>

            <div className="ev-filters">
                <input
                    className="ev-input"
                    name="category"
                    placeholder="Категорія…"
                    value={category}
                    onChange={onChangeFilter}
                />
                <input
                    className="ev-input"
                    name="tag"
                    placeholder="Тег…"
                    value={tag}
                    onChange={onChangeFilter}
                />
                <select
                    className="ev-input"
                    value={sort}
                    onChange={(e) => onSort(e.target.value.split(",")[0])}
                    title="Сортування"
                >
                    <option value="startAt,asc">За датою (зрост.)</option>
                    <option value="startAt,desc">За датою (спад.)</option>
                    <option value="name,asc">За назвою (A→Z)</option>
                    <option value="name,desc">За назвою (Z→A)</option>
                </select>
            </div>

            {error && (
                <div className="ev-alert ev-alert--error">
                    <strong>Помилка:</strong>{" "}
                    {error?.status === 401 ? "Необхідна авторизація." : `HTTP ${error?.status || "?"}`}
                </div>
            )}

            <div className="ev-card">
                <table className="ev-table">
                    <thead>
                    <tr>
                        <th onClick={() => onSort("name")} role="button">Назва</th>
                        <th onClick={() => onSort("startAt")} role="button">Початок</th>
                        <th>Локація</th>
                        <th>Дії</th>
                    </tr>
                    </thead>
                    <tbody>
                    {content.length === 0 && (
                        <tr>
                            <td colSpan={4} className="ev-empty">Немає івентів</td>
                        </tr>
                    )}
                    {content.map((ev) => (
                        <tr key={ev.id}>
                            <td>{ev.name}</td>
                            <td>{new Date(ev.startAt).toLocaleString()}</td>
                            <td>{ev.location || "—"}</td>
                            <td>
                                <Link className="ev-link" to={`/events/${encodeURIComponent(ev.id)}`}>Відкрити</Link>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>

                {totalPages > 1 && (
                    <div className="ev-pg">
                        <button className="ev-btn" disabled={page <= 0 || loading} onClick={() => gotoPage(page - 1)}>Назад</button>
                        <span className="ev-pg__info">Сторінка {page + 1} з {totalPages}</span>
                        <button className="ev-btn" disabled={page + 1 >= totalPages || loading} onClick={() => gotoPage(page + 1)}>Далі</button>
                    </div>
                )}
            </div>

            <style>{STYLES}</style>
        </div>
    );
}

const STYLES = `
.ev-wrap{max-width:1100px;margin:0 auto;padding:16px}
.ev-topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.ev-h1{margin:0;font-size:24px}
.ev-filters{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0 12px}
.ev-input{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:8px 10px}
.ev-btn{display:inline-flex;align-items:center;height:34px;padding:0 12px;border:1px solid #d1d5db;border-radius:10px;background:#fff;cursor:pointer;text-decoration:none;color:#111827}
.ev-card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden}
.ev-table{width:100%;border-collapse:collapse}
.ev-table th,.ev-table td{padding:10px 12px;border-bottom:1px solid #f3f4f6;text-align:left}
.ev-table th[role=button]{cursor:pointer}
.ev-empty{padding:18px;text-align:center;color:#6b7280}
.ev-pg{display:flex;gap:8px;align-items:center;justify-content:center;padding:10px}
.ev-pg__info{font-size:14px;color:#374151}
.ev-alert{margin:8px 0;padding:10px 12px;border-radius:10px;border:1px solid #fecdd3;background:#fff1f2;color:#b91c1c}
.ev-link{color:#2563eb}
`;
