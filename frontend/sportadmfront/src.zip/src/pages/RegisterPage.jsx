// src/pages/RegisterPage.jsx
import { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext.jsx";
import { useNavigate, Link } from "react-router-dom";

export default function RegisterPage() {
    const { register, user } = useAuth();
    const [form, setForm] = useState({ username: "", password: "", role: "user" });
    const [error, setError] = useState("");
    const navigate = useNavigate();

    useEffect(() => { if (user) navigate("/dashboard", { replace: true }); }, [user, navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        try {
            await register(form.username, form.password, form.role);
            navigate("/dashboard", { replace: true });
        } catch (err) {
            setError(err.message || "Помилка реєстрації");
        }
    };

    return (
        <div className="container py-4">
            <h2>Реєстрація</h2>
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label className="form-label">Логін</label>
                    <input className="form-control"
                           value={form.username}
                           onChange={e => setForm(f => ({ ...f, username: e.target.value }))} />
                </div>
                <div className="mb-3">
                    <label className="form-label">Пароль</label>
                    <input type="password" className="form-control"
                           value={form.password}
                           onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
                </div>
                <div className="mb-3">
                    <label className="form-label">Роль</label>
                    <select className="form-select"
                            value={form.role}
                            onChange={e => setForm(f => ({ ...f, role: e.target.value }))}>
                        <option value="user">Користувач</option>
                        <option value="admin">Адміністратор</option>
                    </select>
                </div>
                <button className="btn btn-primary" type="submit">Створити</button>
                <Link to="/login" className="btn btn-link">Увійти</Link>
            </form>
        </div>
    );
}
