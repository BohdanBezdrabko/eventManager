import { useAuth } from "../context/AuthContext";
import { useEffect, useState } from "react";
import { getUserEvents } from "../services/eventRegistrations.js";
import { Calendar, MapPin, User, Shield } from "lucide-react";

export default function DashboardPage() {
    const { user } = useAuth();
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchEvents = async () => {
            if (user?.id) {
                try {
                    const data = await getUserEvents(user.id);
                    setEvents(data);
                } catch (err) {
                    console.error("Помилка завантаження івентів:", err);
                } finally {
                    setLoading(false);
                }
            } else {
                setLoading(false);
            }
        };

        fetchEvents();
    }, [user]);

    return (
        <div className="container py-5">
            <div className="card shadow-lg border-0 rounded-3">
                <div className="card-body p-4">
                    <h2 className="mb-4">Особистий кабінет</h2>

                    {user ? (
                        <div className="mb-4">
                            <h5>
                                <User className="me-2" size={20} />
                                {user.username}
                            </h5>
                            <div>
                                <Shield className="me-2" size={20} />
                                {Array.isArray(user.roles) && user.roles.length > 0 ? (
                                    user.roles.map((r) => (
                                        <span key={r} className="badge bg-secondary me-2">
                                            {r}
                                        </span>
                                    ))
                                ) : (
                                    <span className="text-muted">без ролей</span>
                                )}
                            </div>
                        </div>
                    ) : (
                        <p>Користувач не авторизований</p>
                    )}

                    <h4 className="mt-4">Мої івенти</h4>
                    {loading ? (
                        <p>Завантаження...</p>
                    ) : events.length > 0 ? (
                        <ul className="list-group">
                            {events.map((event) => (
                                <li key={event.id} className="list-group-item">
                                    <Calendar className="me-2" size={18} />
                                    <strong>{event.name}</strong> – {event.location}
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p>Немає зареєстрованих івентів</p>
                    )}
                </div>
            </div>
        </div>
    );
}
