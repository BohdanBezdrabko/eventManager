import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { getUserEvents } from "../services/eventRegistrations.js";


export default function DashboardPage() {
    const { user, booting } = useAuth();
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");


    useEffect(() => {
        if (booting) return; // чекаємо ініціалізацію токена
        if (!user) { setLoading(false); return; }


        (async () => {
            try {
                const data = await getUserEvents(user); // спроба за username, потім за id
                setEvents(Array.isArray(data) ? data : []);
            } catch (e) {
                console.error("Помилка завантаження івентів:", e);
                setError(e?.message || "Error");
            } finally {
                setLoading(false);
            }
        })();
    }, [user, booting]);


    if (loading) return <div className="container py-4">Завантаження…</div>;
    if (!user) return <div className="container py-4">Потрібен вхід у систему.</div>;
    if (error) return <div className="container py-4 text-danger">Помилка: {error}</div>;


    return (
        <div className="container py-4">
            <h2 className="mb-3">Мої реєстрації</h2>
            {events.length === 0 ? (
                <div>Немає подій.</div>
            ) : (
                <ul className="list-group">
                    {events.map((e) => (
                        <li key={e.id ?? `${e.eventId}-${e.userId}`} className="list-group-item">
                            <div className="fw-semibold">{e.eventName ?? e.name ?? `Подія #${e.eventId ?? e.id}`}</div>
                            <div className="small text-muted">{e.location ?? e.place ?? "—"}</div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}