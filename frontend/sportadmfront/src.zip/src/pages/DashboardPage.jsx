import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { getMyRegistrations } from "@/services/eventRegistrations";

function byStartAsc(a, b) {
    const ta = new Date(a.startAt || 0).getTime() || 0;
    const tb = new Date(b.startAt || 0).getTime() || 0;
    return ta - tb;
}

function EventItem({ ev }) {
    const start = ev.startAt || "";
    const capacity = Number(ev.capacity || 0) || "∞";
    const registered = Number(ev.registeredCount || 0) || 0;

    return (
        <Link
            to={`/events/${ev.id}`}
            className="list-group-item list-group-item-action d-flex justify-content-between align-items-center"
        >
            <div>
                <div className="fw-semibold">{ev.name}</div>
                <div className="small text-muted">
                    {start} • {ev.location || "—"}
                </div>
            </div>
            <span className="badge text-bg-primary">{registered} / {capacity}</span>
        </Link>
    );
}

export default function DashboardPage() {
    const { user } = useAuth(); // захищено RequireAuth
    const uid = user?.id ?? null;

    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState("");
    const [events, setEvents] = useState([]);

    useEffect(() => {
        let ignore = false;
        (async () => {
            try {
                setLoading(true);
                const regs = await getMyRegistrations();
                if (ignore) return;
                const list = (Array.isArray(regs) ? regs : [])
                    .map(r => r?.event || r)
                    .filter(Boolean);
                setEvents(list);
            } catch (e) {
                if (!ignore) setErr(e?.message || "Не вдалося завантажити ваші івенти");
            } finally {
                if (!ignore) setLoading(false);
            }
        })();
        return () => { ignore = true; };
    }, [uid]);

    const { upcoming, past } = useMemo(() => {
        const now = Date.now();
        const up = [], pa = [];
        for (const ev of events) {
            const ts = new Date(ev.startAt || 0).getTime();
            if (Number.isFinite(ts) && ts < now) pa.push(ev); else up.push(ev);
        }
        up.sort(byStartAsc);
        pa.sort(byStartAsc).reverse();
        return { upcoming: up, past: pa };
    }, [events]);

    if (loading) return <div className="container py-5 text-center">Завантаження…</div>;
    if (err) return <div className="container py-5"><div className="alert alert-danger">{err}</div></div>;

    return (
        <div className="container py-4">
            <h1 className="mb-4">Кабінет</h1>
            <div className="row g-4">
                <div className="col-12 col-xl-7">
                    <div className="card border-0 shadow-sm rounded-4">
                        <div className="card-body p-4">
                            <div className="d-flex justify-content-between align-items-center mb-3">
                                <h5 className="mb-0">Мої івенти — майбутні</h5>
                                <span className="badge text-bg-secondary">{upcoming.length}</span>
                            </div>
                            {upcoming.length === 0 ? (
                                <div className="alert alert-secondary mb-0">Немає записів.</div>
                            ) : (
                                <div className="list-group">
                                    {upcoming.map(ev => <EventItem key={ev.id} ev={ev} />)}
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className="col-12 col-xl-5">
                    <div className="card border-0 shadow-sm rounded-4">
                        <div className="card-body p-4">
                            <div className="d-flex justify-content-between align-items-center mb-3">
                                <h5 className="mb-0">Мої івенти — минулі</h5>
                                <span className="badge text-bg-secondary">{past.length}</span>
                            </div>
                            {past.length === 0 ? (
                                <div className="alert alert-secondary mb-0">Ще нічого не минуло.</div>
                            ) : (
                                <div className="list-group">
                                    {past.map(ev => <EventItem key={ev.id} ev={ev} />)}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            <div className="mt-4 d-flex gap-2">
                <Link to="/events" className="btn btn-outline-secondary">Усі івенти</Link>
            </div>
        </div>
    );
}
