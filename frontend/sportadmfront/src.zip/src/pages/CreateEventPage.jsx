import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createEvent } from "@/services/events";
import { AlertCircle } from "lucide-react";

export default function CreateEventPage() {
    const navigate = useNavigate();
    const [form, setForm] = useState({
        name: "",
        startAt: "",        // ISO: "2025-09-20T18:00"
        location: "",
        capacity: "",
        coverUrl: "",
        description: "",
    });
    const [submitting, setSubmitting] = useState(false);
    const [err, setErr] = useState(null);

    const onChange = (e) => {
        const { name, value } = e.target;
        setForm((f) => ({ ...f, [name]: value }));
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        setErr(null);
        setSubmitting(true);
        try {
            const payload = {
                name: form.name.trim(),
                startAt: form.startAt ? new Date(form.startAt).toISOString().slice(0,19) : null, // LocalDateTime format
                location: form.location.trim(),
                capacity: form.capacity ? Number(form.capacity) : null,
                coverUrl: form.coverUrl?.trim() || null,
                description: form.description?.trim() || null,
            };
            const saved = await createEvent(payload);
            navigate(`/events/${saved.id}`);
        } catch (e2) {
            setErr(e2.message || "Помилка створення");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="container py-4">
            <h2 className="mb-3">Створити івент</h2>

            {err && (
                <div className="alert alert-danger d-flex align-items-center" role="alert">
                    <AlertCircle size={18} className="me-2" /> {err}
                </div>
            )}

            <form onSubmit={onSubmit} className="card shadow-sm">
                <div className="card-body">
                    <div className="mb-3">
                        <label className="form-label">Назва</label>
                        <input name="name" className="form-control" value={form.name} onChange={onChange} required />
                    </div>

                    <div className="mb-3">
                        <label className="form-label">Дата і час</label>
                        <input name="startAt" type="datetime-local" className="form-control" value={form.startAt} onChange={onChange} required />
                    </div>

                    <div className="mb-3">
                        <label className="form-label">Локація</label>
                        <input name="location" className="form-control" value={form.location} onChange={onChange} required />
                    </div>

                    <div className="mb-3">
                        <label className="form-label">Місткість</label>
                        <input name="capacity" type="number" min="1" className="form-control" value={form.capacity} onChange={onChange} />
                    </div>

                    <div className="mb-3">
                        <label className="form-label">Cover URL</label>
                        <input name="coverUrl" className="form-control" value={form.coverUrl} onChange={onChange} />
                    </div>

                    <div className="mb-3">
                        <label className="form-label">Опис</label>
                        <textarea name="description" rows="4" className="form-control" value={form.description} onChange={onChange} />
                    </div>

                    <div className="d-flex gap-2">
                        <button type="submit" className="btn btn-primary" disabled={submitting}>
                            {submitting ? "Створення…" : "Створити"}
                        </button>
                        <button type="button" className="btn btn-outline-secondary" onClick={() => navigate(-1)} disabled={submitting}>
                            Скасувати
                        </button>
                    </div>
                </div>
            </form>
        </div>
    );
}
